package com.scanbubble

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var statusCamera: TextView
    private lateinit var statusAccessibility: TextView
    private lateinit var statusOverlay: TextView
    private lateinit var shortcutGroup: RadioGroup

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusCamera = findViewById(R.id.status_camera)
        statusAccessibility = findViewById(R.id.status_accessibility)
        statusOverlay = findViewById(R.id.status_overlay)
        shortcutGroup = findViewById(R.id.group_shortcut)

        findViewById<Button>(R.id.btn_camera).setOnClickListener {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
        findViewById<Button>(R.id.btn_accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btn_overlay).setOnClickListener {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        findViewById<Button>(R.id.btn_test).setOnClickListener {
            startActivity(Intent(this, ScanActivity::class.java))
        }

        setupShortcutGroup()
        setupSwitch(R.id.switch_bubble, Prefs.bubbleEnabled(this)) {
            Prefs.setBubbleEnabled(this, it)
            ScanAccessibilityService.instance?.refreshFromPrefs()
        }
        setupSwitch(R.id.switch_autopaste, Prefs.autoPaste(this)) { Prefs.setAutoPaste(this, it) }
        setupSwitch(R.id.switch_enter, Prefs.pressEnter(this)) { Prefs.setPressEnter(this, it) }
        setupSwitch(R.id.switch_vibrate, Prefs.vibrate(this)) { Prefs.setVibrate(this, it) }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun setupSwitch(id: Int, initial: Boolean, onChange: (Boolean) -> Unit) {
        findViewById<SwitchMaterial>(id).apply {
            isChecked = initial
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
    }

    private fun setupShortcutGroup() {
        val checkedId = when (Prefs.shortcutMode(this)) {
            Prefs.MODE_DOUBLE_UP -> R.id.radio_double_up
            Prefs.MODE_BOTH -> R.id.radio_both
            Prefs.MODE_OFF -> R.id.radio_off
            else -> R.id.radio_double_down
        }
        findViewById<RadioButton>(checkedId).isChecked = true
        shortcutGroup.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                R.id.radio_double_up -> Prefs.MODE_DOUBLE_UP
                R.id.radio_both -> Prefs.MODE_BOTH
                R.id.radio_off -> Prefs.MODE_OFF
                else -> Prefs.MODE_DOUBLE_DOWN
            }
            Prefs.setShortcutMode(this, mode)
        }
    }

    private fun updateStatus() {
        val cameraOk = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        setStatus(statusCamera, cameraOk)
        setStatus(statusAccessibility, isAccessibilityEnabled())
        setStatus(statusOverlay, Settings.canDrawOverlays(this))
    }

    private fun setStatus(view: TextView, ok: Boolean) {
        view.setText(if (ok) R.string.status_ok else R.string.status_todo)
        view.setTextColor(ContextCompat.getColor(this, if (ok) R.color.ok else R.color.todo))
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val ours = ComponentName(this, ScanAccessibilityService::class.java)
        val splitter = TextUtils.SimpleStringSplitter(':').apply { setString(enabled) }
        while (splitter.hasNext()) {
            if (ComponentName.unflattenFromString(splitter.next()) == ours) return true
        }
        return false
    }
}
