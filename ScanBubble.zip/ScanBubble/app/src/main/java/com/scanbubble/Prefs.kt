package com.scanbubble

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val MODE_DOUBLE_DOWN = "double_down"
    const val MODE_DOUBLE_UP = "double_up"
    const val MODE_BOTH = "both"
    const val MODE_OFF = "off"

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("scanbubble", Context.MODE_PRIVATE)

    fun shortcutMode(c: Context): String =
        sp(c).getString("shortcut", MODE_DOUBLE_DOWN) ?: MODE_DOUBLE_DOWN

    fun setShortcutMode(c: Context, value: String) =
        sp(c).edit().putString("shortcut", value).apply()

    fun bubbleEnabled(c: Context) = sp(c).getBoolean("bubble", true)
    fun setBubbleEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("bubble", v).apply()

    fun autoPaste(c: Context) = sp(c).getBoolean("autopaste", true)
    fun setAutoPaste(c: Context, v: Boolean) = sp(c).edit().putBoolean("autopaste", v).apply()

    fun pressEnter(c: Context) = sp(c).getBoolean("enter", false)
    fun setPressEnter(c: Context, v: Boolean) = sp(c).edit().putBoolean("enter", v).apply()

    fun vibrate(c: Context) = sp(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibrate", v).apply()

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", -1)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", -1)
    fun setBubblePos(c: Context, x: Int, y: Int) =
        sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply()
}
