package com.scanbubble

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Service d'accessibilité qui fait trois choses :
 *  1. écoute les touches de volume (raccourci) ;
 *  2. affiche la bulle flottante ;
 *  3. colle le code scanné dans le champ de texte qui a le focus.
 */
class ScanAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScanAccessibilityService? = null

        private const val DOUBLE_PRESS_MS = 450L
        private const val PASTE_DELAY_MS = 450L
        private const val PASTE_RETRY_MS = 350L
        private const val PASTE_MAX_TRIES = 4
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    // --- bulle ---
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    // --- raccourci volume ---
    private var lastDownTime = 0L
    private var upHeld = false
    private var downHeld = false
    private var comboFired = false
    private val swallowUp = mutableSetOf<Int>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshFromPrefs()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        removeBubble()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeBubble()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Raccourci touches de volume
    // ------------------------------------------------------------------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_DOWN && code != KeyEvent.KEYCODE_VOLUME_UP) return false

        val mode = Prefs.shortcutMode(this)
        if (mode == Prefs.MODE_OFF) return false

        // Suivi de l'état des deux touches
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (code == KeyEvent.KEYCODE_VOLUME_UP) upHeld = true else downHeld = true
            }
            KeyEvent.ACTION_UP -> {
                if (code == KeyEvent.KEYCODE_VOLUME_UP) upHeld = false else downHeld = false
                if (!upHeld && !downHeld) comboFired = false
            }
        }

        // On avale le relâchement (et les répétitions) d'une touche dont l'appui a été intercepté
        if (event.action == KeyEvent.ACTION_UP && swallowUp.remove(code)) return true
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0 && swallowUp.contains(code)) {
            return true
        }
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false

        when (mode) {
            Prefs.MODE_DOUBLE_DOWN, Prefs.MODE_DOUBLE_UP -> {
                val target = if (mode == Prefs.MODE_DOUBLE_DOWN) {
                    KeyEvent.KEYCODE_VOLUME_DOWN
                } else {
                    KeyEvent.KEYCODE_VOLUME_UP
                }
                if (code != target) return false

                val now = SystemClock.uptimeMillis()
                if (now - lastDownTime <= DOUBLE_PRESS_MS) {
                    lastDownTime = 0L
                    swallowUp.add(code)
                    startScan()
                    return true
                }
                lastDownTime = now
                return false
            }

            Prefs.MODE_BOTH -> {
                if (upHeld && downHeld && !comboFired) {
                    comboFired = true
                    swallowUp.add(code)
                    startScan()
                    return true
                }
                return false
            }
        }
        return false
    }

    // ------------------------------------------------------------------
    // Lancement du scan
    // ------------------------------------------------------------------

    fun startScan() {
        handler.post {
            if (ScanActivity.active) return@post
            setBubbleVisible(false)
            val intent = Intent(this, ScanActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            startActivity(intent)
        }
    }

    /** Appelé par ScanActivity quand elle se ferme (avec ou sans résultat). */
    fun onScanClosed() {
        handler.post { setBubbleVisible(true) }
    }

    /**
     * Appelé par ScanActivity quand un code a été lu. Le code est déjà dans le presse-papiers ;
     * on attend que l'appli précédente reprenne le focus puis on le colle dans le champ actif.
     */
    fun deliver(code: String) {
        if (!Prefs.autoPaste(this)) {
            toast(getString(R.string.toast_copied, code))
            return
        }
        handler.postDelayed({ tryPaste(code, 1) }, PASTE_DELAY_MS)
    }

    private fun tryPaste(code: String, attempt: Int) {
        if (pasteIntoFocusedField()) {
            toast(getString(R.string.toast_pasted, code))
        } else if (attempt < PASTE_MAX_TRIES) {
            handler.postDelayed({ tryPaste(code, attempt + 1) }, PASTE_RETRY_MS)
        } else {
            // Pas de champ de texte actif : le code reste simplement dans le presse-papiers
            toast(getString(R.string.toast_copied, code))
        }
    }

    private fun pasteIntoFocusedField(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!node.isEditable) return false

        // ACTION_PASTE insère le presse-papiers à la position du curseur
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)

        if (!ok) {
            // Repli : on réécrit le texte du champ avec le code ajouté à la fin
            val clip = ContextCompat.getSystemService(this, android.content.ClipboardManager::class.java)
            val code = clip?.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    current + code
                )
            }
            ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        if (ok && Prefs.pressEnter(this) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    private fun toast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // Bulle flottante
    // ------------------------------------------------------------------

    /** À appeler quand les réglages changent. */
    fun refreshFromPrefs() {
        handler.post {
            if (Prefs.bubbleEnabled(this)) showBubble() else removeBubble()
        }
    }

    private fun setBubbleVisible(visible: Boolean) {
        val view = bubble
        if (view == null) {
            if (visible && Prefs.bubbleEnabled(this)) showBubble()
            return
        }
        view.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        if (bubble != null) return
        val size = dp(56)
        val metrics = resources.displayMetrics

        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_scan)
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ContextCompat.getColor(context, R.color.bubble))
            }
            elevation = dp(6).toFloat()
            contentDescription = getString(R.string.bubble_description)
        }

        val savedX = Prefs.bubbleX(this)
        val savedY = Prefs.bubbleY(this)
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (savedX >= 0) savedX else metrics.widthPixels - size
            y = if (savedY >= 0) savedY else metrics.heightPixels / 3
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) moved = true
                        if (moved) {
                            lp.x = (startX + dx).toInt().coerceIn(0, metrics.widthPixels - size)
                            lp.y = (startY + dy).toInt().coerceIn(0, metrics.heightPixels - size)
                            wm.updateViewLayout(v, lp)
                        }
                        return true
                    }

                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            v.performClick()
                            startScan()
                        } else {
                            // Aimantation sur le bord gauche ou droit
                            lp.x = if (lp.x + size / 2 < metrics.widthPixels / 2) {
                                0
                            } else {
                                metrics.widthPixels - size
                            }
                            wm.updateViewLayout(v, lp)
                            Prefs.setBubblePos(this@ScanAccessibilityService, lp.x, lp.y)
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(view, lp)
            bubble = view
            bubbleParams = lp
        } catch (e: Exception) {
            bubble = null
            bubbleParams = null
        }
    }

    private fun removeBubble() {
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubble = null
        bubbleParams = null
    }
}
